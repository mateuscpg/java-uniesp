package com.uniesp.aula1.padroesdeprojetos.provaAV1;

public interface Animal
{

    public String getNomeEspecie () ;

    public String getNomeAnimal () ;
}
